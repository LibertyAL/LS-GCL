import torch
import torch.nn as nn
import torch.nn.functional as F

from torch_geometric.nn.inits import reset
from sklearn.linear_model import LogisticRegression


class MLP(nn.Module): # 两层比较好
    def __init__(self, in_dim, out_dim):
        super(MLP, self).__init__()
        self.fcs = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.PReLU(),
           nn.Linear(out_dim, out_dim),
            nn.PReLU(),
            # nn.Linear(out_dim, out_dim),
            # nn.PReLU(),
        )

        self.fcs1 = nn.Sequential(
            nn.Linear(in_dim, out_dim),
            nn.PReLU())
        # self.linear_shortcut = nn.Linear(in_dim, out_dim)

    def forward(self, x):
        # return self.fcs(x) + self.linear_shortcut(x)
        return self.fcs(x) + self.fcs1(x) + x  # 很有用


class model(nn.Module):


    def __init__(self, hidden_channels, encoder1, encoder2, pool, scorer):# , tau=0.5
        super(model, self).__init__()

        self.hidden_channels = hidden_channels

        # self.local_mlp = MLP(hidden_channels, hidden_channels) # 子图encoder+local_mlp
        '''两个视角用同一个映射投比较好'''
        self.global_mlp = MLP(hidden_channels, hidden_channels) # 全图encoder+global_mlp

        self.encoder1 = encoder1 # 子图encoder
        self.encoder2 = encoder2 # 全图encoder

        self.pool = pool
        self.scorer = scorer
        '''Cora数据集上，marhin = 0.5最佳；
           Citeseer数据集上，marhin = 0.75最佳'''
        self.marginloss = nn.MarginRankingLoss(0.5, reduction='mean')
        self.sigmoid = nn.Sigmoid()
        self.reset_parameters()

        # self.tau: float = tau

    def reset_parameters(self):

        reset(self.encoder1)
        reset(self.encoder2)
        reset(self.pool)
        reset(self.global_mlp)
        # reset(self.local_mlp)

        reset(self.scorer)


    ## Return node and subgraph representations of each node before and after being shuffled
    # def forward(self, x, edge_index, Gdata, batch=None, index=None):
    def forward(self, x, edge_index, Gdatax, Gdataedge_index, batch=None, index=None):


        hidden = self.encoder1(x, edge_index)
        if index is None:
            return hidden

        # 返回每一个子图的中心节点的嵌入表示
        z = hidden[index]
        # 返回每一个节点对应的子图的嵌入表示
        summary = self.pool(hidden, edge_index, batch)

        ## 两层GCN
        # Goutput = self.encoder2(Gdata)
        ## 单层GCN
        Goutput = self.encoder2(Gdatax, Gdataedge_index)

        ## local_MLP转换
        # z = self.local_mlp(z)
        # summary = self.local_mlp(summary)

        ## global_MLP转换
        z = self.global_mlp(z)
        summary = self.global_mlp(summary)
        Goutput = self.global_mlp(Goutput)

        return z, summary, Goutput

    # # 计算MI损失函数
    # def sim(self, z1: torch.Tensor, z2: torch.Tensor):
    #     z1 = F.normalize(z1)
    #     z2 = F.normalize(z2)
    #     return torch.mm(z1, z2.t())
    #
    # def semi_loss(self, z1: torch.Tensor, z2: torch.Tensor):
    #     f = lambda x: torch.exp(x / self.tau)
    #     refl_sim = f(self.sim(z1, z1))
    #     between_sim = f(self.sim(z1, z2))
    #
    #     return -torch.log(
    #         between_sim.diag()
    #         / (refl_sim.sum(1) + between_sim.sum(1) - refl_sim.diag()))

    def loss(self, hidden1, summary1, Goutput1):


        ## 针对局部子图进行的loss训练
        # Computes the margin objective.
        shuf_index = torch.randperm(summary1.size(0))

        hidden2 = hidden1[shuf_index]
        summary2 = summary1[shuf_index]

        logits_aa1 = torch.sigmoid(torch.sum(hidden1 * summary1, dim=-1))
        logits_bb1 = torch.sigmoid(torch.sum(hidden2 * summary2, dim=-1))
        logits_ab1 = torch.sigmoid(torch.sum(hidden1 * summary2, dim=-1))
        logits_ba1 = torch.sigmoid(torch.sum(hidden2 * summary1, dim=-1))

        TotalLoss1 = 0.0
        ones = torch.ones(logits_aa1.size(0)) # 1表示前面一个大，-1表示后面一个大，margin表示相差的值
        TotalLoss1 += self.marginloss(logits_aa1, logits_ba1, ones)
        TotalLoss1 += self.marginloss(logits_bb1, logits_ab1, ones)

        ## 针对全图进行的loss训练
        Goutput2 = Goutput1[shuf_index]
#
        logits_aa2= torch.sigmoid(torch.sum(hidden1 * Goutput1, dim=-1))
        logits_bb2 = torch.sigmoid(torch.sum(hidden2 * Goutput2, dim=-1))
        logits_ab2 = torch.sigmoid(torch.sum(hidden1 * Goutput2, dim=-1))
        logits_ba2 = torch.sigmoid(torch.sum(hidden2 * Goutput1, dim=-1))

        TotalLoss2 = 0.0
        ones = torch.ones(logits_aa2.size(0))
        TotalLoss2 += self.marginloss(logits_aa2, logits_ba2, ones)
        TotalLoss2 += self.marginloss(logits_bb2, logits_ab2, ones)
# #
        logits_aa3 = torch.sigmoid(torch.sum(summary1 * Goutput1, dim=-1))
        logits_bb3 = torch.sigmoid(torch.sum(summary2 * Goutput2, dim=-1))
        logits_ab3 = torch.sigmoid(torch.sum(summary1 * Goutput2, dim=-1))
        logits_ba3 = torch.sigmoid(torch.sum(summary2 * Goutput1, dim=-1))

        TotalLoss3 = 0.0
        ones = torch.ones(logits_aa1.size(0))
        TotalLoss3 += self.marginloss(logits_aa3, logits_ba3, ones)
        TotalLoss3 += self.marginloss(logits_bb3, logits_ab3, ones)
#
#
#         # # 加上一个基于全图信息的损失函数
#         # l1 = self.semi_loss(hidden1, Goutput1)
#         # l2 = self.semi_loss(Goutput1, hidden1)
#         # ret = (l1 + l2) * 0.5
#         # ret = ret.mean()
#
        TotalLoss = (TotalLoss1 + TotalLoss2 + TotalLoss3) / 3

        return TotalLoss

        # return ret

    def test(self, train_z, train_y, val_z, val_y, test_z, test_y, solver='lbfgs',
             multi_class='auto', *args, **kwargs):
        r"""Evaluates latent space quality via a logistic regression downstream task."""
        clf = LogisticRegression(solver=solver, multi_class=multi_class, *args,
                                 **kwargs).fit(train_z.detach().cpu().numpy(),
                                               train_y.detach().cpu().numpy())
        val_acc = clf.score(val_z.detach().cpu().numpy(), val_y.detach().cpu().numpy())
        test_acc = clf.score(test_z.detach().cpu().numpy(), test_y.detach().cpu().numpy())
        return val_acc, test_acc







