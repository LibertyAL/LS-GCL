import argparse, os
import math
import torch
import random
import numpy as np
from torch_geometric.datasets import Planetoid, Amazon, CitationFull
import torch_geometric.transforms as T

from utils_mp import Subgraph, preprocess
from subgcon import SugbCon
from model import Encoder, Scorer, Pool, GCN
from mode_test import model

import warnings
warnings.filterwarnings("ignore", category=Warning)
import time


def get_parser():
    parser = argparse.ArgumentParser(description='Description: Script to run our model.')
    parser.add_argument('--dataset', help='Amazon-Photo and Amazon-Computer', default='Cora_ML')
    parser.add_argument('--subgraph_size', type=int, help='subgraph size', default=20) ## 子图中节点的数量. 更改子图中节点的数量需要重新保存文件，不会自动覆盖
    parser.add_argument('--n_order', type=int, help='order of neighbor nodes', default=10)  ##游走的次数
    parser.add_argument('--hidden_size', type=int, help='hidden size', default=1000) # 745
    # parser.add_argument('--mid_size', type=int, help='mid size', default=512)


    return parser


if __name__ == '__main__':
    parser = get_parser()
    try:
        args = parser.parse_args()
    except:
        exit()
    print(args)

    # # 设置随机种子检查参数的影响
    # seed = 3
    # random.seed(seed)
    # np.random.seed(seed)
    # torch.manual_seed(seed)

    # Loading data
    # data = Planetoid(root='D:\\我的桌面\\A【正在进行的任务】\\AAAAA【今日工作】\\Subg-Con-master\\Subg-Con-master\\dataset\\' + args.dataset, name=args.dataset)
    data = CitationFull(root='D:\\我的桌面\\A【正在进行的任务】\\AAAAA【今日工作】\\Subg-Con-master\\Subg-Con-master\\dataset\\' + args.dataset, name=args.dataset)
    num_classes = data.num_classes ## 节点的类别数目
    data = data[0]
    num_node = data.x.size(0)

    train_mask = torch.zeros(num_node, dtype=torch.bool)
    test_mask = torch.zeros(num_node, dtype=torch.bool)
    val_mask = torch.zeros(num_node, dtype=torch.bool)
    for c in range(num_classes):
        idx = (data.y == c).nonzero(as_tuple=False).view(-1)
        idx = idx[torch.randperm(idx.size(0))[:20]]
        train_mask[idx] = True
    print(torch.nonzero(train_mask > 0, as_tuple=False).shape)  # 10类，每类20个，共200个。

    idx = idx.numpy().tolist()
    nodelist = list(range(num_node))
    mylist1 = list(set(nodelist) - set(idx))  # 删去训练集节点索引
    val_list = random.sample(mylist1, 500)

    mylist2 = list(set(nodelist) - set(idx) - set(val_list))  # 删去训练集，验证集对应节点索引
    test_list = random.sample(mylist2, 1000)

    val_mask[val_list] = True
    test_mask[test_list] = True
    print(train_mask)
    print(val_mask.shape)
    print(test_mask.shape)
    print(torch.count_nonzero(test_mask).item())

    # Setting up the subgraph extractor
    ppr_path = 'D:\\我的桌面\\A【正在进行的任务】\\AAAAA【今日工作】\\Subg-Con-master\\Subg-Con-master\\dataset\\Cora_ML\\Cora_ML' + args.dataset

    subgraph = Subgraph(data.x, data.edge_index, ppr_path, args.subgraph_size, args.n_order)
    # subgraph = Subgraph(x1, data.edge_index, ppr_path, args.subgraph_size, args.n_order)

    subgraph.build()

    # Setting up the model and optimizer
    # model = model(
    #     hidden_channels=args.hidden_size,
    #     encoder1=Encoder(data.num_features, args.hidden_size),
    #     encoder2=GCN(data.num_features, args.mid_size, args.hidden_size),
    #     pool=Pool(in_channels=args.hidden_size),
    #     scorer=Scorer(args.hidden_size))

    model = model(
        hidden_channels=args.hidden_size,
        encoder1=Encoder(data.num_features, args.hidden_size),
        encoder2=Encoder(data.num_features, args.hidden_size),
        pool=Pool(in_channels=args.hidden_size),
        scorer=Scorer(args.hidden_size))

    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-5) # , weight_decay=1e-5
    # scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', factor=0.5, patience=4, verbose=True)
    # neighbor = torch.load('D:\\我的桌面\\A【正在进行的任务】\\AAAAA【今日工作】\\Subg-Con-master\\Subg-Con-master\\dataset\\Cora\\CoraCora_neighbor' )
    # print(neighbor[2707])

    def train(epoch):
        # Model training
        model.train()
        optimizer.zero_grad()
        ## 返回所有节点的索引
        sample_idx = list(range(num_node))
        batch, index = subgraph.search(sample_idx)
        # z, summary, Goutput = model(batch.x, batch.edge_index, data, batch.batch, index)
        z, summary, Goutput = model(batch.x, batch.edge_index, data.x, data.edge_index, batch.batch, index)

        loss = model.loss(z, summary, Goutput)
        loss.backward()
        # scheduler.step(loss)
        # print("第%d个epoch的学习率：%f" % (epoch, optimizer.param_groups[0]['lr']))
        optimizer.step()

        return loss.item()


    def test(model):
        model.eval()
        with torch.no_grad():
            sample_idx = list(range(num_node))
            batch, index = subgraph.search(sample_idx)
            # z, summary, Goutput = model(batch.x, batch.edge_index, data, batch.batch, index)
            z, summary, Goutput = model(batch.x, batch.edge_index, data.x, data.edge_index, batch.batch, index)

            get_all_node_emb = z # 中心节点的输出作为最终的嵌入表示
            # get_all_node_emb = Goutput # 中心节点的输出作为最终的嵌入表示， 很差


            train_z = get_all_node_emb[train_mask]
            val_z = get_all_node_emb[val_mask]
            test_z = get_all_node_emb[test_mask]


        train_y = data.y[train_mask]
        val_y = data.y[val_mask]
        test_y = data.y[test_mask]


        val_acc, test_acc = model.test(train_z, train_y, val_z, val_y, test_z, test_y)
        print('val_acc = {} test_acc = {}'.format(val_acc, test_acc))
        return val_acc, test_acc

    time0 = time.time()


    print('Start training !!!')
    best_acc_from_val = 0
    best_val_acc = 0
    best_ts_acc = 0
    max_val = 0
    stop_cnt = 0
    patience = 50

    for epoch in range(10000):
        loss = train(epoch)
        print('epoch = {}, loss = {}'.format(epoch, loss))
        val_acc, test_acc = test(model)
        best_val_acc = max(best_val_acc, val_acc)
        best_ts_acc = max(best_ts_acc, test_acc)
        if val_acc >= max_val:
            max_val = val_acc
            best_acc_from_val = test_acc
            stop_cnt = 0
        else:
            stop_cnt += 1
        print('best_val_acc = {}, best_test_acc = {}'.format(best_val_acc, best_ts_acc))
        if stop_cnt >= patience:
            break
    print('best_acc_from_val = {}'.format(best_acc_from_val))

    time1 = time.time()

    all_time = (time1-time0)/60
    print("训练时间共计：", all_time)