from pylab import *
plt.rcParams['font.sans-serif'] = ['SimHei']       # 让图形显示中文
plt.rcParams['axes.unicode_minus']=False
plt.rcParams['xtick.direction'] = 'in'#将x周的刻度线方向设置向内
plt.rcParams['ytick.direction'] = 'in'#将y轴的刻度方向设置向内
rcParams['axes.titlepad'] = 15  #调整标题与图的间隔距离

# # 输入数据


# x_p_data = [0,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95,1]
# y1_gat = [0.797,0.822,0.828,0.829,0.835,0.837,0.837,0.842,0.838,0.844,0.84,0.842,0.833,0.829,0.827,0.823,0.834,0.829,0.833,0.825]
# y2_sigat =[0.798, 0.805,0.824,0.784,0.737,0.696,0.656]

# x_p_data = [700,800,900,1000,1100,1200,1300,1400]
# y1_gat = [0.822,0.827,0.825,0.844,0.842,0.832,0.83,0.828]
# x_p_data = [5,10,15,20,25,30,35]
# y1_gat = [0.81,0.826,0.836,0.844,0.844,0.844,0.844]

# x_p_data = [0,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95,1]
# y1_gat = [0.71,0.726,0.723,0.718,0.718,0.722,0.724,0.725,0.724,0.724,0.724,0.721,0.723,0.724,0.723,0.728,0.726,0.727,0.725,0.724,0.725]

# x_p_data = [500,1000,1500,2000,2500,3000]
# y1_gat = [0.713,0.728,0.719,0.72,0.733,0.733]

# x_p_data = [0,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95,1]
# y1_gat = [0.834,0.851,0.861,0.863,0.863,0.869,0.871,0.867,0.87,0.868,0.869,0.867,0.866,0.864,0.866,0.865,0.862,0.862,0.86,0.86,0.857]

# x_p_data = [5,10,15,20,25,30]
# y1_gat = [0.849,0.869,0.868,0.871,0.871,0.871]

# x_p_data = [500,1000,1500,2000,2500]
# y1_gat = [0.864,0.871,0.859,0.859,0.872]

# x_p_data = [0.0001,0.0005,0.001,0.0015,0.002]
# y1_gat = [0.868,0.868,0.871,0.864,0.864]

# x_p_data = [0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5]
# y1_gat = [0.78,0.782,0.795,0.784,0.784,0.815,0.79,0.79,0.725]

# x_p_data = [400,450,500]
# y1_gat = [0.797,0.815,0.789]

# x_p_data = [10,15,20,25]
# y1_gat = [0.771,0.796,0.815,0.815]

# x_p_data = [0.0005,0.001,0.005,0.01]
# y1_gat = [0.793,0.815,0.782,0.779]

# x_p_data = [5,10,15,20,25,30,35]
# y1_gat = [0.719,0.728,0.72,0.725,0.725,0.725,0.725]

x_p_data = [0.0001,0.0005,0.001,0.0015,0.002]
y1_gat = [0.838,0.84,0.844,0.84,0.844]

# plot中参数的含义分别是横轴值，纵轴值，颜色，透明度和标签
# plt.plot(x_p_data, y_katz , 'ro-', color='blue', alpha=0.8, label="katz")
plt.plot(x_p_data, y1_gat , 'ro-', color='red', alpha=0.8, label="Cora")
# plt.plot(x_p_data, y2_sigat, 'ro-', color='green', alpha=0.8, label='SiGAT')
# plt.plot(x_pubmed, y_pubmed_data3 , 'ro-', color='red', alpha=0.8, label="STGAT")

#改变刻度的字体
ax = plt.gca()
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]

# plt.axhline(y=0.71, c="green", alpha=0.8, label="GAT+CN") # 水平基准线
# plt.axhline(y=0.706, c="blue", alpha=0.8, label="GAT") # 水平基准线

plt.legend(loc="upper right",borderaxespad=0.1,prop={'family': 'Times New Roman','weight': 'normal', 'size': 10})
font_legend1 = {'family': 'SimHei','weight': 'normal', 'size': 16}
font_legend2 = {'family': 'Times New Roman','weight': 'normal', 'size': 16}

# plt.ylim(0.8, 0.9)
plt.xlabel('lr',font_legend2)
plt.ylabel('accuracy',font_legend2)
# plt.title('Denity based Human proteins (Stelzl) dataset',font_legend2) #设置标题名称
plt.gcf().subplots_adjust(left=0.15,bottom=0.15)#调整横坐标标签的位置
plt.show()

# 字体